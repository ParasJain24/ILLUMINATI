package com.example.parasajmera.generic;


import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.os.Handler;

public class Firstpage extends Activity {
    private static int SPLASH_TIME_OUT = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firstpage);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(Firstpage.this,Second.class);
                startActivity(i);


                finish();
            }
        }, SPLASH_TIME_OUT);
    }
}











